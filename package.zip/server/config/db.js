module.exports = {
  //local MongoDB deployment ->
  "URI": "mongodb+srv://Edgar:rNzMfPvGt6nKjjzq@midtermf2020server.z5feb.mongodb.net/Book?retryWrites=true&w=majority"
};
